-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2016 at 09:41 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bloodbd`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE IF NOT EXISTS `tbl_admin` (
  `admin_id` int(3) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(100) NOT NULL,
  `email_address` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `email_address`, `password`) VALUES
(1, 'wahidullah', 'admin@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`category_id`, `category_name`, `publication_status`) VALUES
(4, 'A+(A POSITIVE)', 1),
(5, 'A- (A NEGETIVE)', 1),
(6, 'B+ (B POSITIVE)', 1),
(7, 'B- (B NEGATIVE)', 1),
(8, 'AB+ (AB POSITIVE)', 1),
(9, 'AB- (AB NEGATIVE)', 1),
(10, 'O+ (O POSITIVE)', 1),
(11, 'O- (O NEGATIVE)', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_disctrict`
--

CREATE TABLE IF NOT EXISTS `tbl_disctrict` (
  `disc_id` int(11) NOT NULL AUTO_INCREMENT,
  `disc_name` varchar(100) NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`disc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tbl_disctrict`
--

INSERT INTO `tbl_disctrict` (`disc_id`, `disc_name`, `publication_status`) VALUES
(3, 'Dhaka', 1),
(4, 'Kishoregonj', 1),
(5, 'Maymensingho', 1),
(6, 'Chittagong', 1),
(7, 'Rajshahi', 1),
(8, 'Nowakali', 1),
(9, 'Borisal', 1),
(10, 'Rongpur', 1),
(11, 'Norshingdi', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_logo`
--

CREATE TABLE IF NOT EXISTS `tbl_logo` (
  `logo_id` int(11) NOT NULL AUTO_INCREMENT,
  `logo_title` varchar(100) NOT NULL,
  `logo_image` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`logo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_logo`
--

INSERT INTO `tbl_logo` (`logo_id`, `logo_title`, `logo_image`, `publication_status`) VALUES
(2, 'logo', '../assets/logo_images/download (1).jpg', 1),
(3, 'header', '../assets/logo_images/donate-blood-logo-vector-1563703.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slogan`
--

CREATE TABLE IF NOT EXISTS `tbl_slogan` (
  `slogan_id` int(11) NOT NULL AUTO_INCREMENT,
  `slogan` varchar(100) NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`slogan_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_slogan`
--

INSERT INTO `tbl_slogan` (`slogan_id`, `slogan`, `publication_status`) VALUES
(1, 'Blood Owners Should Be Blood doner', 0),
(2, 'Every Drop of Blood Counts, Give Blood Tody', 1),
(3, 'Donate Blood, Save Life', 0),
(4, 'Donate Blood, Save Life', 0),
(5, 'Donate! It is a bloody Good Jobs', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_status`
--

CREATE TABLE IF NOT EXISTS `tbl_status` (
  `status_id` int(11) NOT NULL AUTO_INCREMENT,
  `status_name` varchar(100) NOT NULL,
  `publication_status` tinyint(1) NOT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_status`
--

INSERT INTO `tbl_status` (`status_id`, `status_name`, `publication_status`) VALUES
(6, 'If Urgent,I can donate', 1),
(7, 'Donate Blood', 1),
(8, 'No Interested Yet, Donate Future', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
